import { Instagram } from 'lucide-react';
import { GALLERY_IMAGES } from '@/data';

export default function Gallery() {
  return (
    <section id="gallery" className="relative px-4 py-20 sm:px-6 sm:py-28 lg:px-8">
      <div className="mx-auto max-w-content">
        <div className="reveal mx-auto max-w-2xl text-center">
          <p className="section-eyebrow justify-center">
            <span className="h-px w-6 bg-amber-500" /> Gallery
          </p>
          <h2 className="mt-5 font-display text-3xl font-bold text-white text-balance sm:text-4xl">
            A look inside the vibe
          </h2>
          <p className="mt-4 text-base leading-relaxed text-amber-50/70">
            Food, drinks, music, and moments — see what a night at Plan B X Hangover feels like.
          </p>
        </div>

        <div className="mt-10 grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-4">
          {GALLERY_IMAGES.map((img, idx) => (
            <div
              key={img.src}
              className={`reveal group relative overflow-hidden rounded-2xl border border-white/5 ${
                idx === 0 ? 'col-span-2 row-span-2 md:col-span-2 md:row-span-2' : ''
              }`}
              data-reveal-delay={Math.min(idx * 50, 200)}
            >
              <img
                src={img.src}
                alt={img.alt}
                className={`w-full object-cover transition-transform duration-700 group-hover:scale-110 ${
                  idx === 0 ? 'aspect-square md:aspect-[2/2]' : 'aspect-square'
                }`}
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink-950/70 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
            </div>
          ))}
        </div>

        <div className="reveal mt-10 flex justify-center" data-reveal-delay="100">
          <a
            href="https://instagram.com/planbxhangover"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-ghost"
          >
            <Instagram size={18} /> Follow us on Instagram
          </a>
        </div>
      </div>
    </section>
  );
}
