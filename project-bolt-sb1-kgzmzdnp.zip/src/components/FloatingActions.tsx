import { Phone, MessageCircle, UtensilsCrossed, Navigation, ShoppingBag } from 'lucide-react';
import { BUSINESS } from '@/data';

export default function FloatingActions() {
  return (
    <>
      {/* Floating call + WhatsApp (all screens) */}
      <div className="fixed bottom-24 right-4 z-40 flex flex-col gap-3 sm:bottom-6 sm:right-5">
        <a
          href={`tel:${BUSINESS.phone}`}
          className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-500 text-ink-950 shadow-glow-amber transition-transform hover:scale-110 sm:h-14 sm:w-14"
          aria-label="Call now"
        >
          <Phone size={22} />
        </a>
        <a
          href={BUSINESS.whatsappBooking}
          target="_blank"
          rel="noopener noreferrer"
          className="flex h-12 w-12 items-center justify-center rounded-full bg-green-500 text-ink-950 shadow-lg transition-transform hover:scale-110 sm:h-14 sm:w-14"
          aria-label="WhatsApp us"
        >
          <MessageCircle size={22} />
        </a>
      </div>

      {/* Mobile bottom action bar */}
      <nav
        className="fixed bottom-0 left-0 right-0 z-40 grid grid-cols-4 border-t border-white/10 bg-ink-900/95 backdrop-blur-md pb-[env(safe-area-inset-bottom)] lg:hidden"
        aria-label="Quick actions"
      >
        <a
          href={`tel:${BUSINESS.phone}`}
          className="flex flex-col items-center justify-center gap-1 py-2.5 text-[11px] font-medium text-amber-50/80 transition-colors active:bg-white/5"
        >
          <Phone size={20} className="text-amber-400" /> Call
        </a>
        <a
          href="#menu"
          className="flex flex-col items-center justify-center gap-1 py-2.5 text-[11px] font-medium text-amber-50/80 transition-colors active:bg-white/5"
        >
          <UtensilsCrossed size={20} className="text-amber-400" /> Menu
        </a>
        <a
          href={BUSINESS.maps}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center gap-1 py-2.5 text-[11px] font-medium text-amber-50/80 transition-colors active:bg-white/5"
        >
          <Navigation size={20} className="text-amber-400" /> Directions
        </a>
        <a
          href={BUSINESS.zomato}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center gap-1 py-2.5 text-[11px] font-medium text-ink-950"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-amber-500 to-ember">
            <ShoppingBag size={18} />
          </span>
          Order
        </a>
      </nav>
    </>
  );
}
