import { Clock, Music, PartyPopper, MessageCircle } from 'lucide-react';
import { BUSINESS } from '@/data';

const OFFERS = [
  {
    tag: 'Weekdays',
    icon: Clock,
    title: 'Happy Hours',
    desc: 'Selected drinks at special prices, Monday to Thursday from 4 PM to 8 PM. The perfect excuse for an after-work unwind.',
    accent: 'from-amber-500/20 to-transparent',
  },
  {
    tag: 'Weekends',
    icon: Music,
    title: 'Live Music Nights',
    desc: 'Friday and Saturday nights with energetic music, great food, and late-night energy that keeps the room moving.',
    accent: 'from-ember/20 to-transparent',
  },
  {
    tag: 'Groups',
    icon: PartyPopper,
    title: 'Birthday & Group Deals',
    desc: 'Curated food packages, décor options, and group-friendly seating to make every celebration one to remember.',
    accent: 'from-crimson/20 to-transparent',
  },
];

export default function Offers() {
  return (
    <section id="offers" className="relative overflow-hidden px-4 py-20 sm:px-6 sm:py-28 lg:px-8">
      <div className="pointer-events-none absolute -left-20 top-1/4 h-72 w-72 rounded-full bg-ember/10 blur-3xl" />
      <div className="pointer-events-none absolute -right-20 bottom-1/4 h-72 w-72 rounded-full bg-crimson/10 blur-3xl" />

      <div className="mx-auto max-w-content">
        <div className="reveal mx-auto max-w-2xl text-center">
          <p className="section-eyebrow justify-center">
            <span className="h-px w-6 bg-amber-500" /> Offers &amp; Events
          </p>
          <h2 className="mt-5 font-display text-3xl font-bold text-white text-balance sm:text-4xl">
            More reasons to visit
          </h2>
          <p className="mt-4 text-base leading-relaxed text-amber-50/70">
            Sample offers shown for preview. Replace with current promotions before launch.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {OFFERS.map((o, idx) => (
            <article
              key={o.title}
              className="reveal relative overflow-hidden rounded-3xl border border-white/5 bg-ink-800/70 p-7 transition-all duration-300 hover:-translate-y-1.5 hover:border-amber-500/30"
              data-reveal-delay={idx * 100}
            >
              <div className={`absolute inset-0 -z-10 bg-gradient-to-br ${o.accent}`} />
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-500 to-ember text-ink-950">
                <o.icon size={22} />
              </span>
              <p className="mt-5 text-xs font-semibold uppercase tracking-[0.2em] text-amber-400">
                {o.tag}
              </p>
              <h3 className="mt-2 font-display text-2xl font-bold text-white">{o.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-amber-50/65">{o.desc}</p>
            </article>
          ))}
        </div>

        <div className="reveal mt-12 flex justify-center" data-reveal-delay="120">
          <a
            href={BUSINESS.whatsappBooking}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary"
          >
            <MessageCircle size={18} /> Plan Your Visit
          </a>
        </div>
      </div>
    </section>
  );
}
