import { UtensilsCrossed, Wine, Music2, ArrowRight } from 'lucide-react';
import { ABOUT_IMG } from '@/data';

const FEATURES = [
  {
    icon: UtensilsCrossed,
    title: 'Food made for sharing',
    text: 'Burgers, pizzas, pasta, wings, continental plates, and desserts built for the whole table.',
  },
  {
    icon: Wine,
    title: 'Cocktails & mocktails',
    text: 'Classic cocktails, signature drinks, beers on tap, and refreshing mocktails for every mood.',
  },
  {
    icon: Music2,
    title: 'Music & nightlife energy',
    text: 'A lively setting for friends, dates, birthdays, and weekend nights that go late.',
  },
];

export default function About() {
  return (
    <section id="about" className="relative px-4 py-20 sm:px-6 sm:py-28 lg:px-8">
      <div className="mx-auto grid max-w-content items-center gap-12 lg:grid-cols-2 lg:gap-16">
        <div className="reveal relative">
          <div className="absolute -inset-3 -z-10 rounded-[2rem] bg-gradient-to-br from-amber-500/20 via-ember/10 to-transparent blur-2xl" />
          <div className="overflow-hidden rounded-[1.5rem] border border-white/5 shadow-card">
            <img
              src={ABOUT_IMG}
              alt="Warm restaurant interior with wooden seating and neon lights at Plan B X Hangover"
              className="aspect-[4/3] w-full object-cover transition-transform duration-700 hover:scale-105"
              loading="lazy"
            />
          </div>
          <div className="absolute -bottom-6 -right-4 hidden rounded-2xl border border-white/10 bg-ink-900/90 px-5 py-4 backdrop-blur sm:block">
            <p className="font-display text-3xl font-bold text-amber-500">4.9★</p>
            <p className="text-xs text-amber-50/60">Guest experience</p>
          </div>
        </div>

        <div className="reveal" data-reveal-delay="120">
          <p className="section-eyebrow">
            <span className="h-px w-6 bg-amber-500" /> The Experience
          </p>
          <h2 className="mt-5 font-display text-3xl font-bold leading-tight text-white text-balance sm:text-4xl">
            Where HSR comes together after sunset
          </h2>
          <p className="mt-5 text-base leading-relaxed text-amber-50/70">
            Plan B X Hangover is the heartbeat of HSR Layout's nightlife — a bold, energetic space
            where loaded plates, cold drinks, and great music come together. Whether it's a laid-back
            dinner, a birthday celebration, or a late-night catch-up with friends, every visit turns
            into a story worth telling.
          </p>

          <div className="mt-8 flex flex-col gap-4">
            {FEATURES.map((f) => (
              <div
                key={f.title}
                className="flex gap-4 rounded-2xl border border-white/5 bg-ink-800/60 p-5 transition-colors hover:border-amber-500/30"
              >
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 to-ember text-ink-950">
                  <f.icon size={20} />
                </span>
                <div>
                  <h3 className="font-semibold text-white">{f.title}</h3>
                  <p className="mt-1 text-sm text-amber-50/65">{f.text}</p>
                </div>
              </div>
            ))}
          </div>

          <a href="#menu" className="btn-primary mt-8">
            Explore the Menu <ArrowRight size={18} />
          </a>
        </div>
      </div>
    </section>
  );
}
