import { useMemo, useState } from 'react';
import { Download, Star } from 'lucide-react';
import { MENU_FILTERS, MENU_ITEMS, type MenuCategory } from '@/data';

type Filter = 'All' | MenuCategory;

export default function MenuSection() {
  const [active, setActive] = useState<Filter>('All');

  const items = useMemo(
    () => (active === 'All' ? MENU_ITEMS : MENU_ITEMS.filter((i) => i.category === active)),
    [active],
  );

  return (
    <section id="menu" className="relative px-4 py-20 sm:px-6 sm:py-28 lg:px-8">
      <div className="mx-auto max-w-content">
        <div className="reveal mx-auto max-w-2xl text-center">
          <p className="section-eyebrow justify-center">
            <span className="h-px w-6 bg-amber-500" /> Our Menu
          </p>
          <h2 className="mt-5 font-display text-3xl font-bold text-white text-balance sm:text-4xl">
            Made to share. Built to crave.
          </h2>
          <p className="mt-4 text-base leading-relaxed text-amber-50/70">
            Explore crowd favourites across starters, pizzas, burgers, continental dishes, desserts,
            and drinks.
          </p>
        </div>

        <div className="reveal mt-10 flex flex-wrap justify-center gap-2" data-reveal-delay="100">
          {MENU_FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setActive(f)}
              className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${
                active === f
                  ? 'bg-gradient-to-r from-amber-500 to-ember text-ink-950 shadow-glow-amber'
                  : 'border border-white/10 bg-white/5 text-amber-50/70 hover:border-amber-500/40 hover:text-amber-400'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {items.map((item, idx) => (
            <article
              key={item.name}
              className="reveal group flex flex-col overflow-hidden rounded-2xl border border-white/5 bg-ink-800/70 transition-all duration-300 hover:-translate-y-1.5 hover:border-amber-500/30 hover:shadow-card"
              data-reveal-delay={Math.min(idx * 60, 240)}
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={item.image}
                  alt={item.alt}
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  loading="lazy"
                />
                <span className="absolute left-3 top-3 rounded-full bg-ink-950/80 px-3 py-1 text-xs font-semibold text-amber-400 backdrop-blur">
                  {item.category}
                </span>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="font-display text-lg font-bold text-white">{item.name}</h3>
                  <span className="shrink-0 font-semibold text-amber-500">{item.price}</span>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-amber-50/60">{item.description}</p>
                <div className="mt-4 flex items-center gap-1 text-xs text-amber-50/40">
                  <Star size={13} className="fill-amber-500 text-amber-500" />
                  <Star size={13} className="fill-amber-500 text-amber-500" />
                  <Star size={13} className="fill-amber-500 text-amber-500" />
                  <Star size={13} className="fill-amber-500 text-amber-500" />
                  <Star size={13} className="fill-amber-500 text-amber-500" />
                  <span className="ml-1">Guest favourite</span>
                </div>
              </div>
            </article>
          ))}
        </div>

        <div className="reveal mt-12 flex justify-center" data-reveal-delay="120">
          <a href="#" className="btn-ghost" onClick={(e) => e.preventDefault()}>
            <Download size={18} /> Download Full Menu
          </a>
        </div>
      </div>
    </section>
  );
}
