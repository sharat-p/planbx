import { Phone, MessageCircle, MapPin, Instagram, Facebook, UtensilsCrossed } from 'lucide-react';
import { BUSINESS } from '@/data';

const QUICK = [
  { label: 'Menu', href: '#menu' },
  { label: 'Offers', href: '#offers' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'Visit Us', href: '#visit' },
];

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-ink-900 px-4 pt-16 pb-28 sm:px-6 sm:pb-20 lg:px-8">
      <div className="mx-auto max-w-content">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <p className="font-display text-xl font-bold text-white">
              PLAN B <span className="text-amber-500">X</span> HANGOVER
            </p>
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-amber-50/60">
              A lively bar and restaurant in HSR Layout for great food, cocktails, music, and
              memorable nights.
            </p>
            <div className="mt-5 flex gap-3">
              <a
                href={BUSINESS.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-amber-50/70 transition-colors hover:border-amber-500/50 hover:text-amber-400"
                aria-label="Instagram"
              >
                <Instagram size={18} />
              </a>
              <a
                href={BUSINESS.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-amber-50/70 transition-colors hover:border-amber-500/50 hover:text-amber-400"
                aria-label="Facebook"
              >
                <Facebook size={18} />
              </a>
              <a
                href={BUSINESS.zomato}
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-amber-50/70 transition-colors hover:border-amber-500/50 hover:text-amber-400"
                aria-label="Zomato"
              >
                <UtensilsCrossed size={18} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.15em] text-amber-50/45">
              Quick Links
            </h3>
            <ul className="mt-4 flex flex-col gap-2.5">
              {QUICK.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    className="text-sm text-amber-50/70 transition-colors hover:text-amber-400"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.15em] text-amber-50/45">
              Contact
            </h3>
            <ul className="mt-4 flex flex-col gap-3">
              <li>
                <a
                  href={`tel:${BUSINESS.phone}`}
                  className="flex items-center gap-2.5 text-sm text-amber-50/70 transition-colors hover:text-amber-400"
                >
                  <Phone size={16} className="text-amber-500" /> {BUSINESS.phoneDisplay}
                </a>
              </li>
              <li>
                <a
                  href={BUSINESS.whatsappBooking}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2.5 text-sm text-amber-50/70 transition-colors hover:text-green-300"
                >
                  <MessageCircle size={16} className="text-green-400" /> WhatsApp Us
                </a>
              </li>
              <li className="flex items-start gap-2.5 text-sm text-amber-50/70">
                <MapPin size={16} className="mt-0.5 shrink-0 text-amber-500" />
                <span>{BUSINESS.address}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/5 pt-6 sm:flex-row">
          <p className="text-xs text-amber-50/45">
            © 2026 Plan B X Hangover. All rights reserved.{' '}
            <a href="#" className="underline-offset-2 hover:text-amber-400 hover:underline">
              Privacy Policy
            </a>
          </p>
          <p className="text-xs text-amber-50/35">
            Website designed for online visibility and customer conversion.
          </p>
        </div>
      </div>
    </footer>
  );
}
