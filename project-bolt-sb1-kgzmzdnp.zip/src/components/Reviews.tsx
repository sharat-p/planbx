import { Star, ExternalLink } from 'lucide-react';

const REVIEWS = [
  {
    text: 'Great ambience, quick service, and the pizza was excellent. Perfect place for a weekend night out in HSR.',
    rating: 5,
    initials: 'AR',
    source: 'Google Review',
  },
  {
    text: 'Loved the cocktails and the energetic vibe. The loaded fries and burgers are definitely worth trying.',
    rating: 5,
    initials: 'SK',
    source: 'Zomato Review',
  },
  {
    text: 'Nice place for groups. Good music, generous portions, and a lively atmosphere late into the night.',
    rating: 4,
    initials: 'PM',
    source: 'Google Review',
  },
];

function Stars({ n }: { n: number }) {
  return (
    <div className="flex gap-0.5" aria-label={`${n} out of 5 stars`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          size={16}
          className={i < n ? 'fill-amber-500 text-amber-500' : 'text-ink-600'}
        />
      ))}
    </div>
  );
}

export default function Reviews() {
  return (
    <section id="reviews" className="relative px-4 py-20 sm:px-6 sm:py-28 lg:px-8">
      <div className="mx-auto max-w-content">
        <div className="reveal mx-auto max-w-2xl text-center">
          <p className="section-eyebrow justify-center">
            <span className="h-px w-6 bg-amber-500" /> Guest Love
          </p>
          <h2 className="mt-5 font-display text-3xl font-bold text-white text-balance sm:text-4xl">
            What guests say
          </h2>
          <p className="mt-4 text-base leading-relaxed text-amber-50/70">
            Sample testimonials for design preview. Replace with real customer feedback.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {REVIEWS.map((r, idx) => (
            <figure
              key={idx}
              className="reveal flex flex-col rounded-3xl border border-white/5 bg-ink-800/70 p-7 transition-all duration-300 hover:-translate-y-1.5 hover:border-amber-500/30"
              data-reveal-delay={idx * 100}
            >
              <Stars n={r.rating} />
              <blockquote className="mt-4 flex-1 text-sm leading-relaxed text-amber-50/80">
                “{r.text}”
              </blockquote>
              <figcaption className="mt-6 flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-amber-500 to-ember font-semibold text-ink-950">
                  {r.initials}
                </span>
                <div>
                  <p className="text-sm font-semibold text-white">Verified Guest</p>
                  <p className="text-xs text-amber-50/50">{r.source}</p>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>

        <div className="reveal mt-12 flex justify-center" data-reveal-delay="120">
          <a
            href="https://www.google.com/search?q=Plan+B+X+Hangover+HSR+Layout+reviews"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-ghost"
          >
            Read More Reviews on Google <ExternalLink size={16} />
          </a>
        </div>
      </div>
    </section>
  );
}
