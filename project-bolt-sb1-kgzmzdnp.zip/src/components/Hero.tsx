import { Phone, MapPin, ShoppingBag, UtensilsCrossed, Clock, Music, GlassWater, CalendarDays, MessageCircle } from 'lucide-react';
import { BUSINESS, HERO_IMG } from '@/data';

const TONIGHT = [
  { icon: Clock, label: 'Happy Hours', value: '4 PM – 8 PM' },
  { icon: Music, label: 'Live Music', value: 'Friday & Saturday' },
  { icon: CalendarDays, label: 'Weekend Brunch', value: '12 PM onwards' },
  { icon: UtensilsCrossed, label: 'Table Booking', value: 'Call us' },
];

export default function Hero() {
  return (
    <section id="home" className="relative flex min-h-[100svh] items-center overflow-hidden pt-24 pb-16">
      <div className="absolute inset-0 -z-10">
        <img
          src={HERO_IMG}
          alt="Sophisticated bar interior with lush greenery and warm ambient lighting at Plan B X Hangover"
          className="h-full w-full object-cover animate-slow-zoom"
          fetchPriority="high"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/85 to-ink-950/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-transparent to-ink-950/60" />
      </div>

      <div className="mx-auto grid w-full max-w-content gap-12 px-4 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:items-center lg:px-8">
        <div className="reveal" data-reveal-delay="80">
          <p className="section-eyebrow">
            <span className="h-px w-6 bg-amber-500" /> Bar &amp; Restaurant • HSR Layout, Bengaluru
          </p>
          <h1 className="mt-5 font-display text-4xl font-bold leading-[1.08] text-white text-balance sm:text-5xl lg:text-6xl">
            Good Food. <span className="text-amber-500">Cold Drinks.</span> Great Nights.
          </h1>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-amber-50/75 sm:text-lg">
            Plan B X Hangover is your go-to destination in HSR Layout for loaded burgers,
            wood-fired pizza, continental favourites, desserts, cocktails, music, and memorable
            nights out.
          </p>

          <div className="mt-7 flex flex-wrap gap-3">
            <a href="#menu" className="btn-primary">
              <UtensilsCrossed size={18} /> View Menu
            </a>
            <a href={BUSINESS.maps} target="_blank" rel="noopener noreferrer" className="btn-ghost">
              <MapPin size={18} /> Get Directions
            </a>
            <a
              href={BUSINESS.zomato}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-ghost"
            >
              <ShoppingBag size={18} /> Order on Zomato
            </a>
          </div>

          <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-sm text-amber-50/70">
            <li className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-green-400" /> Open Daily
            </li>
            <li className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-amber-500" /> Dine-in &amp; Delivery
            </li>
            <li className="flex items-center gap-2">
              <span className="text-amber-400">★</span> 4.9-star guest experience
            </li>
          </ul>
        </div>

        {/* Tonight card */}
        <div className="reveal glass rounded-3xl p-6 sm:p-7" data-reveal-delay="220">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-xl font-bold text-white">Tonight at Plan B</h2>
            <span className="rounded-full bg-amber-500/15 px-3 py-1 text-xs font-semibold text-amber-400">
              Live now
            </span>
          </div>
          <ul className="mt-5 flex flex-col gap-3">
            {TONIGHT.map((item) => (
              <li
                key={item.label}
                className="flex items-center gap-4 rounded-2xl border border-white/5 bg-white/[0.03] px-4 py-3"
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400">
                  <item.icon size={18} />
                </span>
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-white">{item.label}</p>
                  <p className="text-sm text-amber-50/60">{item.value}</p>
                </div>
              </li>
            ))}
          </ul>
          <a
            href={BUSINESS.whatsappBooking}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-full bg-green-500 px-5 py-3.5 font-semibold text-ink-950 transition-transform hover:-translate-y-0.5"
          >
            <MessageCircle size={18} /> Book a Table on WhatsApp
          </a>
          <a
            href={`tel:${BUSINESS.phone}`}
            className="mt-3 flex w-full items-center justify-center gap-2 text-sm text-amber-50/60 transition-colors hover:text-amber-400"
          >
            <Phone size={15} /> or call {BUSINESS.phoneDisplay}
          </a>
        </div>
      </div>

      <a
        href="#about"
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-1 text-amber-50/40 transition-colors hover:text-amber-400 sm:flex"
        aria-label="Scroll down"
      >
        <span className="text-[11px] uppercase tracking-[0.2em]">Scroll</span>
        <span className="h-9 w-5 rounded-full border border-amber-50/30 p-1">
          <span className="mx-auto block h-2 w-1 animate-float rounded-full bg-amber-400" />
        </span>
      </a>
    </section>
  );
}
