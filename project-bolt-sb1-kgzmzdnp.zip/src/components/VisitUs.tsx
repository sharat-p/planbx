import { MapPin, Clock, Phone, MessageCircle, Navigation, ShoppingBag, Bike } from 'lucide-react';
import { BUSINESS } from '@/data';

const INFO = [
  { icon: MapPin, label: 'Address', value: BUSINESS.address },
  { icon: Clock, label: 'Opening Hours', value: BUSINESS.hours },
  { icon: Phone, label: 'Phone', value: BUSINESS.phoneDisplay },
];

export default function VisitUs() {
  return (
    <section id="visit" className="relative px-4 py-20 sm:px-6 sm:py-28 lg:px-8">
      <div className="mx-auto max-w-content">
        <div className="reveal mx-auto max-w-2xl text-center">
          <p className="section-eyebrow justify-center">
            <span className="h-px w-6 bg-amber-500" /> Visit Us
          </p>
          <h2 className="mt-5 font-display text-3xl font-bold text-white text-balance sm:text-4xl">
            Find us in HSR Layout
          </h2>
          <p className="mt-4 text-base leading-relaxed text-amber-50/70">
            Walk in for dinner and drinks, or order your favourites through Zomato.
          </p>
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-2">
          <div className="reveal rounded-3xl border border-white/5 bg-ink-800/70 p-6 sm:p-8" data-reveal-delay="80">
            <h3 className="font-display text-xl font-bold text-white">Plan B X Hangover</h3>
            <ul className="mt-6 flex flex-col gap-5">
              {INFO.map((item) => (
                <li key={item.label} className="flex gap-4">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400">
                    <item.icon size={18} />
                  </span>
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-[0.15em] text-amber-50/45">
                      {item.label}
                    </p>
                    <p className="mt-0.5 text-sm text-amber-50/80">{item.value}</p>
                  </div>
                </li>
              ))}
            </ul>

            <div className="mt-5 flex items-start gap-4 rounded-2xl border border-white/5 bg-white/[0.03] p-4">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400">
                <Bike size={18} />
              </span>
              <p className="text-sm text-amber-50/70">
                Delivery, dine-out, and takeaway available on Zomato.
              </p>
            </div>

            <div className="mt-7 flex flex-wrap gap-3">
              <a href={BUSINESS.maps} target="_blank" rel="noopener noreferrer" className="btn-primary">
                <Navigation size={18} /> Get Directions
              </a>
              <a href={`tel:${BUSINESS.phone}`} className="btn-ghost">
                <Phone size={18} /> Call Now
              </a>
              <a
                href={BUSINESS.whatsappBooking}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-ghost text-green-300 border-green-400/30"
              >
                <MessageCircle size={18} /> WhatsApp Us
              </a>
              <a
                href={BUSINESS.zomato}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-ghost"
              >
                <ShoppingBag size={18} /> Order on Zomato
              </a>
            </div>
          </div>

          <div
            className="reveal overflow-hidden rounded-3xl border border-white/5 bg-ink-800/70 p-2"
            data-reveal-delay="160"
          >
            <iframe
              title="Map to Plan B X Hangover in HSR Layout, Bengaluru"
              src={BUSINESS.mapEmbed}
              className="h-full min-h-[320px] w-full rounded-2xl border-0 grayscale-[0.2]"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
            />
          </div>
        </div>
      </div>
    </section>
  );
}
