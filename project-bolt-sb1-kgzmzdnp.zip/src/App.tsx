import { useReveal } from '@/hooks/useReveal';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import About from '@/components/About';
import MenuSection from '@/components/MenuSection';
import Gallery from '@/components/Gallery';
import Offers from '@/components/Offers';
import Reviews from '@/components/Reviews';
import VisitUs from '@/components/VisitUs';
import Footer from '@/components/Footer';
import FloatingActions from '@/components/FloatingActions';

export default function App() {
  useReveal();

  return (
    <div className="min-h-screen bg-ink-950 text-amber-50 selection:bg-amber-500/30">
      <Navbar />
      <main>
        <Hero />
        <About />
        <MenuSection />
        <Gallery />
        <Offers />
        <Reviews />
        <VisitUs />
      </main>
      <Footer />
      <FloatingActions />
    </div>
  );
}
