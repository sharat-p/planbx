export const BUSINESS = {
  name: 'Plan B X Hangover',
  phone: '+919620008396',
  phoneDisplay: '+91 96200 08396',
  whatsapp: '919620008396',
  address: '2324, 17th Cross Road, 27th Main, Sector 1, HSR Layout, Bengaluru, Karnataka 560102',
  hours: 'Open daily, 12:00 PM to 1:00 AM',
  instagram: 'https://instagram.com/planbxhangover',
  facebook: 'https://facebook.com/planbxhangover',
  zomato: 'https://www.zomato.com/bangalore/plan-b-x-hangover-hsr-layout',
  maps: 'https://www.google.com/maps/search/?api=1&query=Plan+B+X+Hangover+HSR+Layout+Bengaluru',
  mapEmbed:
    'https://www.google.com/maps?q=Plan+B+X+Hangover+HSR+Layout+Bengaluru&output=embed',
  whatsappBooking:
    'https://wa.me/919620008396?text=' +
    encodeURIComponent('Hi Plan B X Hangover, I would like to book a table.'),
};

export const HERO_IMG =
  'https://images.pexels.com/photos/39552029/pexels-photo-39552029.jpeg?auto=compress&cs=tinysrgb&w=1600';

export const ABOUT_IMG =
  'https://images.pexels.com/photos/9316203/pexels-photo-9316203.jpeg?auto=compress&cs=tinysrgb&w=1200';

export const GALLERY_IMAGES = [
  {
    src: 'https://images.pexels.com/photos/16859958/pexels-photo-16859958.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Vibrant cocktails lined up on the bar counter at Plan B X Hangover',
  },
  {
    src: 'https://images.pexels.com/photos/2788823/pexels-photo-2788823.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Stylish bar interior with decorative lighting, plants and a well-stocked counter',
  },
  {
    src: 'https://images.pexels.com/photos/5054643/pexels-photo-5054643.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Group of friends enjoying drinks and conversation on a rooftop terrace',
  },
  {
    src: 'https://images.pexels.com/photos/30660324/pexels-photo-30660324.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Gourmet burger platter with fries and a refreshing drink at a Bengaluru restaurant',
  },
  {
    src: 'https://images.pexels.com/photos/9609836/pexels-photo-9609836.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Spicy tandoori chicken drumsticks with green chutney, vibrant Indian cuisine',
  },
  {
    src: 'https://images.pexels.com/photos/6531496/pexels-photo-6531496.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Illuminated glasses on the bar under moody red lighting',
  },
  {
    src: 'https://images.pexels.com/photos/30794933/pexels-photo-30794933.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Vibrant mocktails garnished with mint and ice cubes',
  },
  {
    src: 'https://images.pexels.com/photos/36729937/pexels-photo-36729937.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Group of friends taking a selfie with cityscape in the background at dusk',
  },
];

export type MenuCategory =
  | 'Starters'
  | 'Pizza & Pasta'
  | 'Burgers'
  | 'Continental'
  | 'Desserts'
  | 'Beverages'
  | 'Cocktails';

export const MENU_FILTERS: ('All' | MenuCategory)[] = [
  'All',
  'Starters',
  'Pizza & Pasta',
  'Burgers',
  'Continental',
  'Desserts',
  'Beverages',
  'Cocktails',
];

export interface MenuItem {
  name: string;
  description: string;
  price: string;
  category: MenuCategory;
  image: string;
  alt: string;
}

export const MENU_ITEMS: MenuItem[] = [
  {
    name: 'Cheesy Loaded Fries',
    description: 'Crispy fries smothered in molten cheese, jalapeños and herbs.',
    price: '₹299',
    category: 'Starters',
    image:
      'https://images.pexels.com/photos/30622042/pexels-photo-30622042.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Loaded fries with melted cheese and a refreshing drink on a rustic table',
  },
  {
    name: 'Loaded Nachos',
    description: 'Tortilla chips piled with cheese sauce, salsa, beans and sour cream.',
    price: '₹379',
    category: 'Starters',
    image:
      'https://images.pexels.com/photos/15662014/pexels-photo-15662014.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Loaded nachos topped with grilled lime, melted cheese and spicy sauce',
  },
  {
    name: 'Peri Peri Wings',
    description: 'Crunchy chicken wings tossed in a smoky peri peri glaze.',
    price: '₹369',
    category: 'Starters',
    image:
      'https://images.pexels.com/photos/30749028/pexels-photo-30749028.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Spicy glazed chicken wings garnished with sliced vegetables',
  },
  {
    name: 'Fiery Chicken Pizza',
    description: 'Wood-fired pizza with spicy chicken, peppers and stretchy mozzarella.',
    price: '₹449',
    category: 'Pizza & Pasta',
    image:
      'https://images.pexels.com/photos/15832888/pexels-photo-15832888.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Freshly baked pizza with cheese and toppings served with dipping sauces on a wooden tray',
  },
  {
    name: 'Creamy Alfredo Pasta',
    description: 'Fettuccine in a silky parmesan cream sauce with herbs and pepper.',
    price: '₹429',
    category: 'Pizza & Pasta',
    image:
      'https://images.pexels.com/photos/11220208/pexels-photo-11220208.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Creamy fettuccine alfredo pasta plated on a rustic table',
  },
  {
    name: 'Hangover Burger',
    description: 'Juicy double patty, cheddar, caramelised onions and house sauce.',
    price: '₹349',
    category: 'Burgers',
    image:
      'https://images.pexels.com/photos/30660324/pexels-photo-30660324.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Gourmet burger platter with fries and a watermelon drink at a Bengaluru restaurant',
  },
  {
    name: 'Smoky BBQ Chicken Burger',
    description: 'Grilled chicken, smoky BBQ glaze, crisp slaw and brioche bun.',
    price: '₹399',
    category: 'Burgers',
    image:
      'https://images.pexels.com/photos/2983102/pexels-photo-2983102.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Grilled bacon and cheese burger on a wooden board with fiery background',
  },
  {
    name: 'Grilled Chicken Platter',
    description: 'Char-grilled chicken with rice, sautéed vegetables and house dip.',
    price: '₹549',
    category: 'Continental',
    image:
      'https://images.pexels.com/photos/36701439/pexels-photo-36701439.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Plated grilled tandoori chicken dish with vibrant floral garnishes',
  },
  {
    name: 'Molten Choco Lava',
    description: 'Warm chocolate cake with a gooey centre, served with ice cream.',
    price: '₹249',
    category: 'Desserts',
    image:
      'https://images.pexels.com/photos/12927134/pexels-photo-12927134.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Chocolate cake slices adorned with fresh strawberries and chocolate rounds',
  },
  {
    name: 'Smoky Whiskey Sour',
    description: 'Bourbon, fresh lemon, sugar and a touch of smoke over ice.',
    price: '₹499',
    category: 'Cocktails',
    image:
      'https://images.pexels.com/photos/4485391/pexels-photo-4485391.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Bartender pouring whiskey into a glass at a bar counter',
  },
  {
    name: 'Passion Fruit Mojito',
    description: 'Rum, passion fruit, mint, lime and soda over crushed ice.',
    price: '₹299',
    category: 'Beverages',
    image:
      'https://images.pexels.com/photos/30794933/pexels-photo-30794933.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Vibrant mocktails garnished with mint and ice cubes',
  },
  {
    name: 'Classic Cold Coffee',
    description: 'Blended cold coffee with milk, ice cream and a chocolate drizzle.',
    price: '₹249',
    category: 'Beverages',
    image:
      'https://images.pexels.com/photos/4728009/pexels-photo-4728009.jpeg?auto=compress&cs=tinysrgb&w=800',
    alt: 'Iced coffee with swirling cream served in a glass cup surrounded by coffee beans',
  },
];
