/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#0D0B10',
          900: '#131017',
          850: '#191420',
          800: '#1D1822',
          700: '#271F2E',
          600: '#33283D',
        },
        amber: {
          DEFAULT: '#FFB43A',
          50: '#FFF7E6',
          100: '#FFE9BF',
          400: '#FFCB6A',
          500: '#FFB43A',
          600: '#E69A1F',
        },
        ember: {
          DEFAULT: '#FF6A2B',
          400: '#FF8A52',
          500: '#FF6A2B',
          600: '#E5521A',
        },
        crimson: {
          DEFAULT: '#E5455A',
          400: '#F06978',
          500: '#E5455A',
          600: '#C92E43',
        },
      },
      fontFamily: {
        display: ['"Playfair Display"', 'Georgia', 'serif'],
        sans: ['"Inter"', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
      },
      maxWidth: {
        content: '1200px',
      },
      boxShadow: {
        glow: '0 0 60px -15px rgba(255, 106, 43, 0.45)',
        'glow-amber': '0 0 50px -20px rgba(255, 180, 58, 0.5)',
        card: '0 20px 45px -20px rgba(0, 0, 0, 0.7)',
      },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(24px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'slow-zoom': {
          '0%': { transform: 'scale(1)' },
          '100%': { transform: 'scale(1.08)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-6px)' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.7s cubic-bezier(0.22, 1, 0.36, 1) forwards',
        'fade-in': 'fade-in 0.8s ease forwards',
        'slow-zoom': 'slow-zoom 18s ease-in-out infinite alternate',
        float: 'float 3s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
